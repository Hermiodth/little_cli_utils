#!/usr/bin/env python3
"""
C++ Source File Merger - Combines multiple C++ source files into a single file.
"""

import os
import sys
import argparse
from pathlib import Path
from typing import List


def find_cpp_files(directory: str, recursive: bool = True) -> List[Path]:
    """
    Find all C++ source files in the given directory.
    
    Args:
        directory: Directory to search
        recursive: Whether to search recursively
        
    Returns:
        List of Path objects for C++ source files
    """
    extensions = {'.cpp', '.cc', '.cxx', '.c', '.hpp', '.h', '.hxx', '.hh'}
    path = Path(directory)
    
    if not path.exists():
        print(f"Error: Directory '{directory}' does not exist", file=sys.stderr)
        sys.exit(1)
    
    if not path.is_dir():
        print(f"Error: '{directory}' is not a directory", file=sys.stderr)
        sys.exit(1)
    
    cpp_files = []
    
    if recursive:
        for ext in extensions:
            cpp_files.extend(path.rglob(f'*{ext}'))
    else:
        for ext in extensions:
            cpp_files.extend(path.glob(f'*{ext}'))
    
    return sorted(cpp_files)


def merge_files(files: List[Path], base_dir: Path = None) -> None:
    """
    Merge C++ files and print to stdout with separators.
    
    Args:
        files: List of file paths to merge
        base_dir: Base directory for relative paths (optional)
    """
    for file_path in files:
        # Determine the display name
        if base_dir:
            try:
                display_name = file_path.relative_to(base_dir)
            except ValueError:
                display_name = file_path.name
        else:
            display_name = file_path.name
        
        # Print separator
        print("//=============================================")
        print(f"file: {display_name}")
        print("//=============================================")
        
        # Print file contents
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                print(content)
                # Add newline if file doesn't end with one
                if content and not content.endswith('\n'):
                    print()
        except Exception as e:
            print(f"// Error reading file: {e}", file=sys.stderr)
        
        # Add blank line between files
        print()


def main():
    """Main entry point for the cpp-merger CLI."""
    parser = argparse.ArgumentParser(
        description='Merge C++ source files into a single file with separators',
        epilog='Example: cpp-merger /path/to/project > merged.cpp'
    )
    
    parser.add_argument(
        'directory',
        help='Directory containing C++ source files'
    )
    
    parser.add_argument(
        '-n', '--no-recursive',
        action='store_true',
        help='Do not search subdirectories recursively'
    )
    
    parser.add_argument(
        '-r', '--relative-paths',
        action='store_true',
        help='Show relative paths from the base directory instead of just filenames'
    )
    
    parser.add_argument(
        '--version',
        action='version',
        version='cpp-merger 1.0.0'
    )
    
    args = parser.parse_args()
    
    # Find C++ files
    cpp_files = find_cpp_files(args.directory, recursive=not args.no_recursive)
    
    if not cpp_files:
        print(f"Warning: No C++ source files found in '{args.directory}'", file=sys.stderr)
        sys.exit(0)
    
    # Merge files
    base_dir = Path(args.directory).resolve() if args.relative_paths else None
    merge_files(cpp_files, base_dir)


if __name__ == '__main__':
    main()
